export const services = [
  ['Building Construction','Construction solutions for residential, commercial and institutional buildings.'],
  ['Civil Construction','Civil works for suitable infrastructure and site requirements.'],
  ['Structural Construction','Structural building works with a focus on sound construction practice.'],
  ['Steel Reinforcement / Rebar','Reinforcement works for foundations, beams, columns and slabs.'],
  ['Concrete Works','Concrete-related construction works across building projects.'],
  ['Foundations','Foundation construction appropriate to the project design and requirements.'],
  ['Beams and Columns','Structural concrete elements for suitable building projects.'],
  ['Floor Slabs','Floor and slab construction for residential and commercial applications.'],
  ['Retaining Walls','Retaining-wall construction for appropriate site conditions.'],
  ['Roofing and Building Works','Roofing and associated building works.'],
  ['Renovation','Renovation and improvement works for existing buildings.'],
  ['Maintenance','Construction-related maintenance and site support.'],
] as const

export const materialCategories = ['Sand','Bricks','Cement','Lime','Aggregates','Hardcore','Stones','Reinforcement Steel','Roofing Materials','Concrete Materials','Other Materials']

export type Product = {id:string; name:string; slug:string; category:string; description:string; images:string[]; unit:string; price?:number; salePrice?:number; currency:string; stockQuantity?:number; availability:'unknown'|'in-stock'|'out-of-stock'; minimumOrderQuantity:number; deliveryEligible:boolean; featured:boolean; active:boolean}
export const products: Product[] = []
