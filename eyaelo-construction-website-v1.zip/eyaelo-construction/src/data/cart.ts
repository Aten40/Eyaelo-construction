export type CartItem = { productId:string; quantity:number }
export const cartStore = {
  items: [] as CartItem[],
  add(productId:string, quantity=1){ const found=this.items.find(x=>x.productId===productId); if(found) found.quantity+=quantity; else this.items.push({productId,quantity}) },
  remove(productId:string){ this.items=this.items.filter(x=>x.productId!==productId) },
  setQuantity(productId:string, quantity:number){ const found=this.items.find(x=>x.productId===productId); if(found) found.quantity=Math.max(0,quantity) },
  clear(){ this.items=[] }
}
