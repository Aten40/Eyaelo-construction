export type OrderStatus = 'Pending'|'Confirmed'|'Processing'|'Ready'|'Dispatched'|'Delivered'|'Cancelled'
export type DeliveryMethod = 'pickup'|'eyaelo-delivery'
export type Customer = {id:string; name:string; phone:string; email?:string; addresses?:string[]}
export type OrderItem = {productId:string; name:string; quantity:number; unit:string; unitPrice:number}
export type Order = {id:string; customerId:string; items:OrderItem[]; subtotal:number; deliveryFee:number; total:number; status:OrderStatus; deliveryMethod:DeliveryMethod}
export type Category = {id:string; name:string; slug:string; active:boolean}
