# Eyaelo Construction Ltd Website

Production-ready static-first React/Vite/TypeScript website architecture for Eyaelo Construction Ltd.

## Current scope
- Construction website
- Services
- Projects placeholder
- Building Materials catalogue/categories
- Shop in Coming Soon mode
- Quote request frontend
- Material pricing enquiry frontend
- Mobile-first responsive UI
- SEO basics, sitemap and robots.txt
- Future product/cart/checkout architecture
- GitHub Actions build check
- Cloudflare Pages compatible

## Important
`STORE_ENABLED` is `false` in `src/config.ts`. Do not enable online ordering until verified product data, delivery rules, customer workflows and payment integration are ready.

No company contact details, project claims, prices, stock, certifications or customer testimonials have been fabricated.

## Run locally
```bash
npm install
npm run dev
```

Production build:
```bash
npm run build
npm run preview
```

## GitHub
Create a repository and upload the project files. Keep `.env` out of GitHub. Commit `.env.example` only.

## Cloudflare Pages Free
1. Create/sign into Cloudflare.
2. Open Workers & Pages / Pages and choose the Git integration flow.
3. Connect GitHub and select this repository.
4. Build command: `npm run build`.
5. Build output directory: `dist`.
6. Deploy and test the assigned `pages.dev` URL.
7. Add a custom domain later through Cloudflare using the DNS records Cloudflare displays for your account/domain.

Do not invent DNS records. The exact records can vary and must be taken from the Cloudflare dashboard after the domain is added.

## Domain
The domain has not been purchased. Replace `YOUR_DOMAIN_HERE` after a domain is actually acquired and configured.

## Contact configuration
Set verified values in the configuration/environment before launch. Do not put passwords, API keys or payment credentials in source control.

## Future backend
The site is static-first. A backend/API and database can later replace local product data without redesigning the public information architecture.

See `ECOMMERCE_ROADMAP.md` for the activation plan.
